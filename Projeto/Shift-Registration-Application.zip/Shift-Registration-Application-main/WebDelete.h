#pragma once
#include "AbstractMenu.h"

class WebDelete : public AbstractMenu
{
public:
	void process();
};


