#pragma once
#include "AbstractMenu.h"

class WebRegisterRemove : public AbstractMenu
{
public:
	void process();
};

