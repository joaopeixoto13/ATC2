#pragma once
#include "AbstractMenu.h"

class WebRegisterShiftsManual : public AbstractMenu
{
public:
	void process();
};

