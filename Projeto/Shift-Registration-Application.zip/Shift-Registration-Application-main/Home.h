#pragma once
#include "AbstractMenu.h"

class Home : public AbstractMenu
{
public:
	void process();
};

