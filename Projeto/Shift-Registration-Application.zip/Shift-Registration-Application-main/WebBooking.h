#pragma once
#include "AbstractMenu.h"

class WebBooking : public AbstractMenu
{
public:
	void process();
};
