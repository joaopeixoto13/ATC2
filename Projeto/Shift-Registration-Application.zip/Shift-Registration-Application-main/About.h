#pragma once
#include "AbstractMenu.h"

class About : public AbstractMenu
{
public:
	void process();
};

