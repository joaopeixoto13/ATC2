#pragma once
#include "AbstractMenu.h"

class WebGenerate : public AbstractMenu
{
public:
	void process();
};

