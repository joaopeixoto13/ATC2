#pragma once
#include "AbstractMenu.h"

class WebRegisterManual : public AbstractMenu
{
public:
	void process();
};

