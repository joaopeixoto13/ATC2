#pragma once
#include "AbstractMenu.h"

class WebRegisterShiftsManual2 : public AbstractMenu
{
public:
	void process();
};

