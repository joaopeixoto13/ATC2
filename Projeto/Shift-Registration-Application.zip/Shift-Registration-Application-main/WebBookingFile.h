#pragma once
#include "AbstractMenu.h"

class WebBookingFile : public AbstractMenu
{
public:
	void process();
};

