#pragma once
#include "AbstractMenu.h"
class WebBookingRemove : public AbstractMenu
{
public:
	void process();
};

