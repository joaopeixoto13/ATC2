#pragma once
#include "AbstractMenu.h"

class WebRegisterFile : public AbstractMenu
{
	void process();
};

